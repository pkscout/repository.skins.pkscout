# skin.estuary.krypton.pkscout.mod
Mod of Krypton Estuary skin to include Artist Slideshow and allow user to hide widgets on home screen.
